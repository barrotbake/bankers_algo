To compile this use
g++ bankers_algorithm.cpp -lpthread -g -lgomp -std=c++11 -o ba

Then pass
./ba filename